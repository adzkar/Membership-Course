<div class="sidebar-wrapper">
            

    <ul class="nav">
        <li class="active">
            <a href="<?=base_url('admin/dashboard')?>">
                <i class="ti-panel"></i>
                <p>Dashboard</p>
            </a>
        </li>
        <li>
            <a href="<?=base_url('admin/dashboard/post')?>">
                <i class="ti-plus"></i>
                <p>Post</p>
            </a>
        </li>
        <li>
            <a href="<?=base_url('admin/dashboard/logout')?>">
                <i class="ti-arrow-circle-left"></i>
                <p>Logout</p>
            </a>
        </li>
    </ul>
</div>