<h1>Pilih Tingkat yang Ingin Dipilih</h1>
<div class="kotak">
	<ul>
		<li>
			<a href="<?=base_url('member/dashboard/basic')?>">
				<div class="kiri">
					<i class="fa fa-check fa-lg"></i>
				</div>
				<div class="kanan">
					Basic
				</div>
			</a>
		</li>
		<li>
			<a href="<?=base_url('member/dashboard/advance')?>">
				<div class="kiri">
					<i class="fa fa-check fa-lg"></i>
				</div>
				<div class="kanan">
					Advance
				</div>
			</a>
		</li>
	</ul>
</div>
