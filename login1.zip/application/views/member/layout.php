<?php  
	$this->load->view('member/header');
	$this->load->view('member/body');
?>