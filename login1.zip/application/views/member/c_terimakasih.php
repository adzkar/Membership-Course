<img src="<?=base_url('asset/member/img/The-Minions.png')?>" alt="" style="width: 80%">
<p class="deskripsi">Terimakasih Telah Melakukan Pembayaran, Permintaan anda akan segera kami proses... :)</p>
