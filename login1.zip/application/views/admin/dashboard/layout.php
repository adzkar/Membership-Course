<?php  
	$this->load->view('admin/dashboard/header');
	$this->load->view('admin/dashboard/'.$content);
	$this->load->view('admin/dashboard/footer');
?>